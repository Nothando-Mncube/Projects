import { createContext } from 'react';

const StoreApi = createContext(null);

export default StoreApi;
